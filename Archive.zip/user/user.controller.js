let UserService = require('./user.service')

exports.register = (req,res)=>{
    console.log("Body received from client" , req.body)
    UserService.createUser(req.body)
    .then(()=>{
        res.status(201).send({
            message:"User Created "
        })
    } , (error)=>{
        res.status(500).send(error)
    })
}

exports.login = (req,res)=>{
    res.send({
        message:"Here we will do login"
    })
}

exports.allUsers = (req,res)=>{
    res.send({
        message:"Here we will fetch all users"
    })
}



