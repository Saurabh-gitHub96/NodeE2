var UserModel = require('./user.model')

exports.createUser = (data)=>{
    console.log("data received from controller" , data)
    return new Promise((resolve,reject)=>{
        var validatedUserData = new UserModel(data)
        validatedUserData.save().then((result)=>{
            console.log("data whisch is saved into database", result)
            resolve()
        },(error)=>{
            if(error.code==11000){
                reject({
                    errorMessage:"User Already Exists"
                })
            }
            else{
                reject({
                    errorMessage:"Internal Server Error"
                })
            }
        })
    })
}