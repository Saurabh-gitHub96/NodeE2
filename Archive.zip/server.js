let Express = require('express')
let Router = require('./routes')  // required router here
let Mongoose = require('mongoose')
let BodyParser = require('body-parser')
const Port = 5000

let server = Express()
const dburl = "mongodb://localhost:27017/tcsnodeproject" // tcsnodeproject is dbname
Mongoose.connect(dburl, (err,client)=>{
    if(err){
        console.log("Error in connecting to database" , err)
    }
    else{
        console.log("Connected to Database")
    }
})


// server.use() // .use is middleware provided by express
//which is called before reaching any endpoint

server.use(BodyParser.json())
server.use(Router)   // used router here
server.listen(Port,()=>{
    console.log("Server is listening on", Port)
})