let Jwt = require('jsonwebtoken')
exports.isAuthenticated = (req,res,next)=>{
    var token  = req.get('authtoken')
    Jwt.verify(token,'mysecretkey',function(error,data){
        if(data){
            req.body.email = data.email
            next()
        }
        else{
            res.status(403).send({
                errorMessage:"Not Authorised"
            })
        }
    })
}