const nodemailer = require("nodemailer");
let credentials = require("./credentials.js")

exports.sendMail = async (email)=>{  // async returns a promise by default
    let transporter = nodemailer.createTransport({
        service:'gmail',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
          user: credentials.email, // generated ethereal user
          pass: credentials.password, // generated ethereal password
        },
      });

     let info = await  transporter.sendMail({  // reject(error)
        from: '"No Reply 👻" <lekhi.sahab@gmail.com>', // sender address
        to: email, // list of receivers
        subject: "Hello ✔", // Subject line
        text: "Hello world?", // plain text body
        html: "<b>Hello world?</b>", // html body
      })

  return info // resolve(info)
    
}





// async Promise.resolve(info)

