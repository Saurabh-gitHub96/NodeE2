// mongodb is a database whics is a NO sql dtatabase

// mongodb doese structured or query lanagauage to find or store data


//mongodb calls functions to operate on data base

// mongodb stores collections

// collections is grouping of data
// data is stored in a format which is known as documnt in terms
// of mongodb but it is similar to object in javascript 

//lets saya there is so many data stored idn database which is related to users

// we create a collection known as users
// and users will contain documents// each document will have info about each user