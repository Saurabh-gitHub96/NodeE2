// async and await


// getdata()  // they wil take time or they return immediately

// callbacks // promises

// fs.readfile('ashu.resume.text').then(function(){})

// fs.readFile('ashu.txt', function(err,data){})

// After Node 8 
// We can explicitly tell js that please wait on that line which is time consuming
// how we tell tht to javascript

// we ask javascript to await 

var data = await getflights()
// we keep on waiting in line 18 unitl and unless getflights is completed
// which was not the nature of js 
// js by default doest not wait for any line to complete

 function   createUser() {
    // making a db call here to store user into database
    // var result  =  await storeindb()
}

// when ever u need to use wait that await must be wrapped in a async function

// when ulimately by the await keywork u are making it synchronous that why do u needd keyword async
// when ever u neeed to use await that code should be enclosed in a function that is async
