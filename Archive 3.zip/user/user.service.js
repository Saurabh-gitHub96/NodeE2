var UserModel = require('./user.model')
let Mailer = require('../mailer.js')
let Eventemitter =  require('events')
let Jwt = require('jsonwebtoken')

const bcrypt = require('bcrypt');
const saltRounds = 10;
exports.createUser =  (data)=>{
    console.log("data received from controller" , data)
    return new Promise((resolve,reject)=>{
        bcrypt.hash(data.password,saltRounds,function(error,generatedpassword){
console.log("Encrypted password" , error,generatedpassword)
if(generatedpassword){
    data.password = generatedpassword
    var validatedUserData = new UserModel(data)
        validatedUserData.save().then((result)=>{
            console.log("data whisch is saved into database", result)
            Mailer.sendMail(result.email).then((mailresult)=>{
             console.log("Mail is sent" , mailresult)
             resolve(result)
            },(mailerror)=>{
             console.log("Error in sending mail" , mailerror)
             UserModel.deleteOne({email:result.email}).then((resultofremoval)=>{
                console.log("Due to failure in email deleted that user account" , resultofremoval)
                reject({
                    errorMessage:"Internal Server Error"
                })
             },(errorinremoval)=>{
                console.log("Due to failure in email tried to deleted that user account but got error", errorinremoval)
             })
            })
        },(error)=>{
            if(error.code==11000){
                reject({
                    errorMessage:"User Already Exists"
                })
            }
            else{
                reject({
                    errorMessage:"Internal Server Error"
                })
            }
        })
}
else{
    reject({
        errorMessage:"Internal Server Error"
    })
}
        })
        
    })
}


exports.login = (data)=>{
   return new Promise((resolve,reject)=>{
    let query = {email:data.email}
    UserModel.findOne(query).then((userfound)=>{
        if(userfound){
            bcrypt.compare(data.password,userfound.password,function(error,samepassword){
                if(samepassword){
                    var uniquetoken = Jwt.sign({email:data.email},'mysecretkey')
                    resolve({user:userfound,token:uniquetoken})
                }
                else if(!samepassword){
                    reject("Invalid credentials") 
                }
                else{
                    reject("Error")
                }
            })
        }
        else{
            reject("Invalid credentials")
        }
    })
   })   
}

exports.changePassword = async (data)=>{
    var query = {email:data.email}
    var userfound =  await UserModel.findOne(query)
    console.log("user found result" , userfound)
    if(userfound.email){
        var samepassword = bcrypt.compareSync(data.oldpassword,userfound.password)
        console.log("Same password comparision result" , samepassword)
        if(samepassword){
            var hashedpassword = bcrypt.hashSync(data.newpassword,10)
            var updateresult = await UserModel.findOneAndUpdate(query,{$set:{password:hashedpassword}})
            return updateresult
        }
        else{
            return "Old Password Incorrect"
        }
    }
}


exports.deleteUser =  (data)=>{
    let emitter = new Eventemitter()
   UserModel.remove({email:data.email}).then((deleteresult)=>{
    console.log("result of delete", deleteresult)
    if(deleteresult.deletedCount>=1){
        emitter.emit('deleted')
    }
    else{
        emitter.emit('failedtodelete')
    }
   })
    // object of eventemitter type it is capable of emitting custom events
    // syntax to raise a custom message is  --   emitter.emit('message,anydataifrequired)
    return emitter
}

// due to await keyword emitter was no returnded
// .on was not able to get called on undefined








