let Express = require('express')
let router  = Express.Router()
let UserController = require('./user.controller')
let AuthController = require('../auth/auth.controller.js')


router.post('/register', function(req,res,next){
    function validateEmail(email) {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    if(validateEmail(req.body.email)){
        next()
    }
    else{
        res.send({
            errorMessage:"Please Send a Valid Email Syntax"
        })
    }
} ,UserController.register)
router.post('/login', UserController.login)
router.post('/deleteaccount', AuthController.isAuthenticated, UserController.deleteAccount)
router.put('/updatepassword', AuthController.isAuthenticated,UserController.updatePassword)
// router.post('/register, function(req,res){})


module.exports = router


// in GET we cant send body
// If we have to send body use POST