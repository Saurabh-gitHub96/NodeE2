let UserService = require('./user.service')

exports.register = (req,res)=>{
    console.log("Body received from client" , req.body)
    UserService.createUser(req.body)
    .then(()=>{
        res.status(201).send({
            message:"User Created "
        })
    } , (error)=>{
        res.status(500).send(error)
    })
}

exports.login = (req,res)=>{
    console.log("Body received from client" , req.body)
    UserService.login(req.body)
    .then((result)=>{
         res.set('authtoken',result.token) // this sets a custom header into client/http response 
        res.status(200).send({
            email:result.user.email
        })
    } , (error)=>{
       
        res.status(500).send({
            errorMessage:error
        })
    })
}

exports.updatePassword = (req,res)=>{
    UserService.changePassword(req.body)
    .then((result)=>{
       res.status(201).send({
           message:result
       })
   } , (error)=>{
      
       res.status(500).send({
           errorMessage:error
       })
   })
}

exports.deleteAccount = (req,res)=>{
    UserService.deleteUser(req.body)
    .on('deleted', ()=>{
        res.status(200).send({
            message:"User Deleted"
        })
    })
    .on('failedtodelete', ()=>{
        res.status(500).send({
            errorMessage:"Some Error Occured"
        })
    })
}





