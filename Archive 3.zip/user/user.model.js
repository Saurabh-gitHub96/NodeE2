// purpose of this model is to deal with User collection in our database

// in layman terms when we want anything from user collections we 
// will  refer UserModel 


let Mongoose = require('mongoose')

let UserSchema = new Mongoose.Schema({
    name:{type:String,required:true},
    email:{type:String,required:true , unique:true},
    password:{type:String,required:true},
    image:{type:String, default:"No Image Avaiable"},
    createdat:{type : Date , default: new Date()}
})

let UserModel = Mongoose.model('users',UserSchema)
// in line 17 userschema is applied on users collection
module.exports = UserModel



// line 9-16 is basically describing the schema of data that will 
// rside in users collection of database
//this means this validation of schema will be checked before inserting data
// into users collection

// for exmple if your try to insert a document into users collections 
// which does not have password field it will throw werror