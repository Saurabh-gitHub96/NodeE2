let Express = require('express')
let Router = require('./routes')  // required router here
let Mongoose = require('mongoose')
let path = require('path')
let BodyParser = require('body-parser')
var io = require('socket.io')

console.log(".... aregumrnst are" , process.argv, process.argv[2] , process.argv[3])
process.argv.forEach((eachargument)=>{
    console.log(".,,,,,,," , eachargument)
})
const Port = process.env.PORT || process.argv[2] || 5000

let app = Express()

var server = require('http').createServer(app);  


var socketlient = io(server)
// console.log(num1, num2) 
// console.log(num1+num2)
console.log("socket client" , socketlient)

const dburl = "mongodb+srv://ashu_lekhi:ebgE7FmlEINZhx6I@cluster0.w5ixg.mongodb.net/tcsnodeapi?retryWrites=true&w=majority" // tcsnodeproject is dbname
// ur is of two parts addressof mongodb server+ databasename
Mongoose.connect(dburl, (err,client)=>{
    if(err){
        console.log("Error in connecting to database" , err)
    }
    else{
        console.log("Connected to Database")
    }
})


 server.use(Express.static(path.resolve(__dirname,'frontend')))
server.use(BodyParser.json())
server.use('/api',Router)   // used router here


// i want to send html file on browswer when anyone opens
// abc.com
// localhost:port

server.get('/*', (req,res)=>{
    res.sendFile(__dirname+'/frontend/index.html')
})
server.listen(Port,()=>{
    console.log("Server is listening on", Port)
})

// Why it recommended not to use async and await 


//rendering view from nodejs

//Coming to nodejs
// async nature 
// scoping
//objects
//modules
//callbacks 
// promises
// events
// this operator
//arrowfunction
//closures
// async/await


