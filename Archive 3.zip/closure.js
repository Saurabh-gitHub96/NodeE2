
function father(){
    let seats = 0
    return function(){
        return seats++
    }

}



// an inner function returned by outer function is known as closure



let nodetrainig  = father()
let reacttraining  = father()

let gc1 = nodetrainig()
let gc2 = nodetrainig()
let gc3 = nodetrainig()
let gc4 = nodetrainig()
let gc5 = nodetrainig()
let gc6 = nodetrainig()
let gc7 = nodetrainig()
let gc8 = nodetrainig()
let gc9 = nodetrainig()
console.log("seats got to grandchilds are" , gc1)
console.log("seats got to grandchilds are" , gc2)
console.log("seats got to grandchilds are" , gc3)
console.log("seats got to grandchilds are" , gc4)
console.log("seats got to grandchilds are" , gc5)
console.log("seats got to grandchilds are" , gc6)
console.log("seats got to grandchilds are" , gc7)







// nodetrainig()
// nodetrainig()
// nodetrainig()
// reacttraining()

// nodetrainig()
// nodetrainig()
// nodetrainig()
// reacttraining()








