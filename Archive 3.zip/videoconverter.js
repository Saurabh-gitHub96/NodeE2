const hbjs = require('handbrake-js')
 
hbjs.spawn({ input: 'Friends.S01E02.The.One.With.the.Sonogram.at.the.End.720p.BluRay.2CH.x265.HEVC-PSA.mkv' ,output:'Episode1.mp4'})
  .on('error', err => {
      console.log("error " , err)
    // invalid user input, no video found etc
  })
  .on('progress', progress => {
    console.log(
      'Percent complete: %s, ETA: %s',
      progress.percentComplete,
      progress.eta
    )
  })