var express = require('express');
var path = require('path');
var app = express();
var cors = require('cors');
var fs = require('fs');
var bodyparser = require('body-parser');
var mongoose = require('mongoose');
var RoomModel = require('./room.model');
var FileModel  =  require('./file.model');
app.use(cors())
app.use(bodyparser.json());
app.use(express.static(path.join(__dirname, '/client1/build')));
app.use(express.static(__dirname));



var express = require('express')
var multer  = require('multer')
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, __dirname + '/uploads')
  },
  filename: function (req, file, cb) {
      console.log("file received" , file)
      console.log(">>>>>>>>>>>>" , __dirname)
    cb(null, file.originalname)
  }
})
 
var upload = multer({ storage: storage })
 
 
app.post('/upload',upload.single('file'), function (req, res, next) {

  console.log("file uploading...." , req.file , req.files)
 // fs.rename('uploads'req.file.filename,req.file.filename+'.pdf')
 
 var filedata = new FileModel({
     filename:req.file.filename,
     pathname:'files'
 })
 filedata.save().then(function(newfile){
console.log("new file saved",newfile)
sendToClient(newfile.filename)
FileModel.find({pathname:'files'}).then((files)=>{
    console.log("files saved are" , files);
    sendFiles(files)
},
function(error){
 console.log("error in finding files" , error)
})
 
 }, function(error){
console.log("error in file saving")
 })
 
 res.send({
      code:200,
      message:'file uploaded'
  })

})
 
const dburl = "mongodb+srv://ashu_lekhi:ebgE7FmlEINZhx6I@cluster0.w5ixg.mongodb.net/filesharedb?retryWrites=true&w=majority" // tcsnodeproject is dbname

mongoose.connect(dburl)
.then((client)=>{
    console.log("connected to db")
},
(error)=>{
    console.log("error in connecting to db",error)
})



var sendToClient = (data)=>{
    console.log("requested from client",data);
    setTimeout(()=>{
        io.emit('apprequested',data)

    },2000)
}


var sendFiles = (data)=>{
    console.log("requested from client",data);
    setTimeout(()=>{
        io.emit('filesuploaded',data)

    },2000)
}


console.log("path join",path.join(__dirname+'../client1/build/index.html'))

app.get('/file/:filename',(req,res)=>{
    res.download(__dirname+'/uploads/'+req.params.filename)
})

app.get('/:pathname', (req, res) => {
    console.log("page requested" , req.params.pathname)
    var pathname = "/" + req.params.pathname
    RoomModel.findOne({pathname:pathname}).then(
        (code)=>{
           if(code){
               var data = {}
               data["pathname"] = code.pathname;
               data["text"] = code.text;
               console.log(".... data",data);
               sendToClient(data);
               if(pathname=='/files'){
                FileModel.find({pathname:'files'}).then((files)=>{
                    console.log("files saved are" , files);
                    sendFiles(files)
                },
             function(error){
                 console.log("error in finding files" , error)
             })
               }
              
           }
        },
        (err)=>{
            console.log("error in finding code",err);
        }
    )
    res.sendFile(path.join(__dirname+ '/client1/build/index.html'));
});
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname+ '/client1/build/index.html'));
});

//var server = require('http').createServer()




var port  = process.env.PORT || 5000

var server = app.listen(port,()=>{
    console.log("server is listening on" , port );

})

var io = require('socket.io')(server);

io.on('connection',(client)=>{
    client.on('hey',(data)=>{
        console.log("even received at server",data);
        var roomdata = new RoomModel(data)
        RoomModel.updateOne({pathname:data.pathname},data,{upsert:true})
        .then((updateddata)=>{
            console.log("code saved in database" ,updateddata )
            io.emit('datachanged',data)
        },(err)=>{
            console.log("error in saving code",err);
        })
        
    })
})


