// Step 1  - create a blank folder 
// step-2 - npm init - initialise that using npm tool
// step-3 npm install packages be it development packages or any package(npm i package_name)
// step-4 create a server using Express


// Error , Duplicate  , Success

// Using we have to design a backend for user registeration

// one unique thing Email/Phone
// password


// Being a Nodejs developer now we have to design an api which will take credentials from user
// store it into a database so that user can login into theri platform 
// by entering those credentials


// We are playing role of nodejs developer
// We should know about database

// Mongodb 
// using all the concepts as of now
// we are ging to build backend for this project using es6 syntax

// data is same 
// clients web ,mobile,smart tv
// to get the data we reach an endpoint that endpoint is known as Api
// Rest Api is the one in which we can use rest methods -like GET,POST,PUT,DELETE,PATCH,Options  etc
// yesrterday er created rest api using express

// Easy routing and middlewares



// middlewares 

// layman 
// when i go to office i need to make an etry at reception
// making an entry is middle task before reaching a destination

// If u want to book a flight // before booking it u need to check wether user is in 
//loggedin state or not

// server.get('/alladminusers', function(req,res,next){
//     // here we will check authentication 
//     // authentication is playing role of middle ware befor achieveing a task of getting admin users
//     if(marks>50){
//     next()
//     else{
//         resizeBy.send({
//             error:"Sorry Try next time"
//         })
//     }
// }
// } ,function(req,res){
//     console.log("here we will find all admin users and send it to client")
// })

// server.get('/interview',function(req,res,next){
  //  next()
//} , function(req,res,next){}, function(req,res,next){}, function(req,res,next){},function(req,res){})
// server.get('/interviewingoogle' , function(req,res){})
//etchnically a function with 3 parameters req,res,next is is middle ware function
//where next states that there is one more function for required task



// Role of controllers and managers is to speak to clients
// What is our role ?

// Our role is to build the requirements passed on to us by manager/contoller


// serving static resources to client